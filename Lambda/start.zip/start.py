import boto3
ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    filters = [{
        'Name': 'tag:' + os.environ['TAG_KEY'],
        'Values': [os.environ['TAG_VALUE']]
    },
    {
        'Name': 'instance-state-name',
        'Values': ['stopped']
    }]
    
    instances = ec2.describe_instances(Filters=filters)
    InstanceIds = [instance['InstanceId'] for reservation in instances['Reservations'] for instance in reservation['Instances']]
    
    if InstanceIds:
        ec2.start_instances(InstanceIds=InstanceIds)